//
//  HomeViewModel_Improved.swift
//  TeamHub
//
//  Created by Jarvis on 12/02/26.
//

import Foundation
import Combine

//@MainActor
//final class HomeViewModel_Improved: ObservableObject {
//
//    @Published private(set) var employees: [Employee] = []
//    @Published var searchText: String = ""
//    @Published private(set) var isLoading: Bool = false
//    @Published private(set) var errorMessage: String?
//
//    @Published var filter = EmployeeFilter()
//
//    private let getEmployeesUseCase: GetEmployeesUseCase
//    private var hasLoadedOnce: Bool = false
//
//    init(getEmployeesUseCase: GetEmployeesUseCase) {
//        self.getEmployeesUseCase = getEmployeesUseCase
//    }
//
//    var availableDepartments: [String] {
//        Array(Set(employees.map { $0.department }))
//            .filter { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false }
//            .sorted()
//    }
//
//    var availableDesignations: [String] {
//        Array(Set(employees.map { $0.designation }))
//            .filter { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false }
//            .sorted()
//    }
//
//    var filteredEmployees: [Employee] {
//
//        var result = employees
//
//        // 1) Status filter
//        if filter.status == .active {
//            result = result.filter { $0.isActive == true }
//        } else if filter.status == .inactive {
//            result = result.filter { $0.isActive == false }
//        }
//
//        // 2) Department multi-select
//        if filter.selectedDepartments.isEmpty == false {
//            result = result.filter { filter.selectedDepartments.contains($0.department) }
//        }
//
//        // 3) Designation multi-select
//        if filter.selectedDesignations.isEmpty == false {
//            result = result.filter { filter.selectedDesignations.contains($0.designation) }
//        }
//
//        // 4) Search
//        if searchText.isEmpty == false {
//            let query = searchText.lowercased()
//
//            result = result.filter {
//                $0.name.lowercased().contains(query) ||
//                $0.email.lowercased().contains(query) ||
//                $0.department.lowercased().contains(query) ||
//                $0.designation.lowercased().contains(query)
//            }
//        }
//
//        return result
//    }
//
//    func load(forceRefresh: Bool = false) async {
//
//        // Prevent parallel calls
//        if isLoading { return }
//
//        // Prevent re-fetching when view reappears
//        if forceRefresh == false && hasLoadedOnce == true {
//            return
//        }
//
//        isLoading = true
//        errorMessage = nil
//
//        defer {
//            isLoading = false
//        }
//
//        do {
//            employees = try await getEmployeesUseCase.execute(forceRefresh: forceRefresh)
//            hasLoadedOnce = true
//        } catch let error as AppError {
//            errorMessage = error.localizedDescription
//        } catch {
//            errorMessage = AppError.unknown.localizedDescription
//        }
//    }
//}
