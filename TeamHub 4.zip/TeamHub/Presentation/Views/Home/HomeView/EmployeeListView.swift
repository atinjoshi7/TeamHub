//
//  EmployeeListView.swift
//  TeamHub
//
//  Created by Jarvis on 23/02/26.
//

import SwiftUI

struct EmployeeListView: View {

    @ObservedObject var vm: HomeViewModel

    var body: some View {
        List(vm.filteredEmployees) { employee in
            NavigationLink {
                EmployeeDetailsView(employee: employee)
            } label: {
                EmployeeRowView(employee: employee)
            }
        }
        .listStyle(.plain)
        .refreshable {
            await vm.load(forceRefresh: true)
        }
    }
}
