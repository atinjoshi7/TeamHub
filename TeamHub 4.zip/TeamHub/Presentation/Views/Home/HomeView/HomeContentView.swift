//
//  HomeContentView.swift
//  TeamHub
//
//  Created by Jarvis on 23/02/26.
//

import SwiftUI

//struct HomeContentView: View {
//
//    @ObservedObject var vm: HomeViewModel
//   
//    @Binding var showFilterSheet: Bool
//   
//    
//    var body: some View {
//        VStack(spacing: ) {
//
//
//            switch vm.viewState {
//
//            case .loading:
//                LoadingListView()
//
//            case .noInternet:
//                NoInternetView()
//
//            case .emptySearch:
//                NoUserFound()
//
//            case .content:
//                EmployeeListView(vm: vm)
//            }
//        }
//    }
//}
